﻿
namespace CustomClassLibrary
{
    public class SemesterDetails
    {
        public SemesterDetails() {
            sWeeks = 0;
            sStarts = DateTime.Now;
        }
        public int sWeeks;
        public DateTime sStarts;
        public int Weeks
        {
            get { return sWeeks; }
            set { sWeeks = value; }
        }

        public DateTime Starts
        {
            get { return sStarts; }
            set { sStarts = value; }
        }
    }
}
