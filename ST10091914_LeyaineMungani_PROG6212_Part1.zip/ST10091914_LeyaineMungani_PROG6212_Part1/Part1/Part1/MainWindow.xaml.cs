﻿using CustomClassLibrary;
using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace Part1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        readonly ObservableCollection<Module> moduleView = new(); // modules store
        readonly ObservableCollection<SemesterDetails> semesterView = new(); // semester store
        readonly ObservableCollection<ModuleStudyProgress> moduleStudyProgressView = new(); // module study progress store
        public MainWindow()
        {
            InitializeComponent();
            semesterView.Add(item: new SemesterDetails());
        }
       
        private void Save_Module_Button_Click(object sender, RoutedEventArgs e)
        {
            string sWeeks = semesterWeeks.Text;
            var isNumericSw = int.TryParse(sWeeks, out _);
            if (!isNumericSw)
            {
                MessageBox.Show("Semester must be a number", "Message", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            if (moduleCode.Text.Trim().Length == 0)
            {
                MessageBox.Show("Module code is required", "Message", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            else if (moduleView.FirstOrDefault(x => x.Name.Equals(moduleCode.Text.Trim())) != null)
            {
                MessageBox.Show("Module code, " + moduleCode.Text.Trim() + " already added", "Message", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            if (moduleName.Text.Trim().Length == 0)
            {
                MessageBox.Show("Module name is required", "Message", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            else if (moduleView.FirstOrDefault(x => x.Name.Equals(moduleName.Text.Trim())) != null)
            {
                MessageBox.Show("Module name, " + moduleName.Text.Trim() + " already added", "Message", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            string clhr = moduleCHPW.Text;
            var isNumericNi = int.TryParse(clhr, out _);
            if (!isNumericNi)
            {
                MessageBox.Show("Class hours per week must be a number", "Message", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            string mc = moduleCredits.Text;
            var isNumericNs = int.TryParse(mc, out _);
            if (!isNumericNs)
            {
                MessageBox.Show("Credits must be a number", "Message", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            int selfStudyHours = Calculations.CalcNumOfSelfStudyHoursPerWeekPerModule(Convert.ToInt32(mc), Convert.ToInt32(sWeeks), Convert.ToInt32(clhr));
            Module _Module = new(moduleCode.Text.Trim(), moduleName.Text.Trim(),  Convert.ToInt32(clhr), Convert.ToInt32(mc), selfStudyHours);
            moduleView.Add(_Module);
            modulesListView.ItemsSource = moduleView;
            moduleCredits.Text = "";
            moduleCHPW.Text = "";
            moduleCode.Text = "";
            MessageBox.Show("Module " + moduleName.Text.Trim() + " added", "Message", MessageBoxButton.OK, MessageBoxImage.Information);
            moduleName.Text = "";
        }
        
        private void Save_Semester_Start_Date(object sender, RoutedEventArgs e)
        {
            DatePicker datePicker = (DatePicker)sender;
            DateTime selectedDate = datePicker.SelectedDate ?? DateTime.MinValue;

            if (semesterView.Count > 0)
            {
                SemesterDetails semesterDetails = semesterView[0];
                semesterDetails.Starts = selectedDate;
            }
            else
            {
                MessageBox.Show("No Semester found", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Save_Semester_Weeks(object sender, RoutedEventArgs e)
        {
            TextBox textBox = (TextBox)sender;
            string sWeeks = textBox.Text; 
            var isNumericSw = int.TryParse(sWeeks, out _);
            if (!isNumericSw)
            {
                MessageBox.Show("Semester weeks must be a number", "Message", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            SemesterDetails semesterDetails = semesterView[0];
            semesterDetails.Weeks = int.Parse(sWeeks);
        }
       

        private void Save_Study_Progress_Click(object sender, RoutedEventArgs e)
        {
            string code = moduleCodeP.Text;
            if (code.Trim().Length == 0)
            {
                MessageBox.Show("Module code is required", "Message", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            string week = moduleWeekP.Text;
            var isNumericSw = int.TryParse(week, out _);
            if (!isNumericSw)
            {
                MessageBox.Show("Weeks must be a number", "Message", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            string hours = moduleHoursP.Text;
            var isNumericS = int.TryParse(hours, out _);
            if (!isNumericS)
            {
                MessageBox.Show("Hours must be a number", "Message", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            Module module = moduleView.FirstOrDefault((p)=>p.Code.Equals(code));
            if(module == null)
            {
                MessageBox.Show("Module "+code+" not found", "Message", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            moduleStudyProgressView.Add(new ModuleStudyProgress(code, int.Parse(hours), int.Parse(week)));
            module.LastWeekRecorded = int.Parse(week);
            int hoursStudedPerWeek = moduleStudyProgressView.Where(p => p.mCode.Equals(code) && p.mWeekNumber == int.Parse(week)).Sum((t)=>t.mSelfStudyHoursCovered);
            module.LastWeekStdyHrsLeft = Calculations.CalcNumOfSelfStudyHoursPerWeekPerModuleLeft(module.SelfStudyHours, hoursStudedPerWeek);
            ICollectionView view = CollectionViewSource.GetDefaultView(moduleView);
            view.Refresh();
            moduleCodeP.Text = "";
            moduleWeekP.Text = "";
            moduleHoursP.Text = "";
            MessageBox.Show("Progress updated for module "+code, "Message", MessageBoxButton.OK, MessageBoxImage.Information);

        }

     
    }
}
