﻿
namespace CustomClassLibrary
{
    public class Calculations
    {
        public static int CalcNumOfSelfStudyHoursPerWeekPerModule(int credits,int nWeeks,int classHoursPerWeek)
        {
            return ((credits * 10) / nWeeks)- classHoursPerWeek; // negative numbers implies that you have exceeded the allotted time
        }
        public static int CalcNumOfSelfStudyHoursPerWeekPerModuleLeft(int totalHrs,int hrStudied)
        {
            return totalHrs - hrStudied;
        }
    }
}
