﻿
namespace CustomClassLibrary
{
    public class ModuleStudyProgress
    {
        public ModuleStudyProgress(string Code, int hoursCovered,int weekNumber)
        {
            mCode = Code;
            mSelfStudyHoursCovered = hoursCovered;
            WeekNumber = weekNumber;
            mDate = DateTime.MinValue; // will be recorded every time new record is created
        }
        // variables as class members
        public string mCode;
        public int mSelfStudyHoursCovered;
        public int mWeekNumber;
        public DateTime mDate;
        public string Code
        {
            get { return mCode; }
            set { mCode = value; }
        }
        public int SelfStudyHoursCovered
        {
            get { return mSelfStudyHoursCovered; }
            set { mSelfStudyHoursCovered = value; }
        }
        public int WeekNumber
        {
            get { return mWeekNumber; }
            set { mWeekNumber = value; }
        }
        public DateTime StdyDate
        {
            get { return mDate; }
            set { mDate = value; }
        }
    }
}
