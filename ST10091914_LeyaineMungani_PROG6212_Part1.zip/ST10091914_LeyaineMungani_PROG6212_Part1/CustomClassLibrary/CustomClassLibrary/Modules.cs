﻿namespace CustomClassLibrary
{
    public class Module
    {
        public Module(string Code,string Name,int hPW,int credits,int sSH) { 
            mCode = Code;
            mName = Name;
            mHoursPerWeek = hPW;
            mCredits = credits;
            mSelfStudyHours = sSH;
        }
        // variables as class members
        public string mCode;
        public string mName;
        public int mCredits;
        public int mHoursPerWeek;
        public int mSelfStudyHours;
        public int mLastWeekRecorded;
        public int mLastWeekStdyHrsLeft;

        // properties to encapsulate the variables
        public string Code
        {
            get { return mCode; }
            set { mCode = value; }
        }

        public string Name
        {
            get { return mName; }
            set { mName = value; }
        }
        public int Credits
        {
            get { return mCredits; }
            set { mCredits = value; }
        }
        public int HoursPerWeek
        {
            get { return mHoursPerWeek; }
            set { mHoursPerWeek = value; }
        }
        public int SelfStudyHours
        {
            get { return mSelfStudyHours; }
            set { mSelfStudyHours = value; }
        }
        public int LastWeekRecorded
        {
            get { return mLastWeekRecorded; }
            set { mLastWeekRecorded = value; }
        }
        public int LastWeekStdyHrsLeft
        {
            get { return mLastWeekStdyHrsLeft; }
            set { mLastWeekStdyHrsLeft = value; }
        }
    }
}